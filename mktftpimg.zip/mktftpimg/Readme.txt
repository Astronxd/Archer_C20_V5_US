How to Make TFTP Images w/ mktftpimg
Many people complained after bricking their non-US hw variants by flashing them with my build. Since I don't have access to other C20 v5 variants, it's hard to determine whether it's my fault or not. I made mktftpimg so you can make a stock tftp image.

Again, I'm not responsible for any damages. I personally broke my C20 v5 once by flashing it too many times. Apparently, flashing your too many times in a short period of time can damage your hw. EXERCISE TRIGGER DISCIPLINE.

You will need
mktftpimg binary. Build it yourself or download it from releases
A stock image of your variant. Just google your variant and download it from TP-Link's website
On Linux
./mktftpimg Archer_C20v5_US_0.9.1_4.16_up_boot[181213-rel33336].bin tp_recovery.bin 512 196608
On Windows(cmd.exe)
mktftpimg.exe Archer_C20v5_US_0.9.1_4.16_up_boot[181213-rel33336].bin tp_recovery.bin 512 196608
Notes
Archer_C20v5_US_0.9.1_4.16_up_boot[181213-rel33336].bin is the name of the stock image. Change it to your stock image.

512 is the size of header(sizeof(struct fw_header) is 512: exb A, exb B). The actual binary that the hardware loads starts after the header.

196608(0x30000) is the size of the first boot loader region. The TFTP recovery program skips 196608 bytes of the downloaded image when copying into the flash. Stupid design if you ask me. This number(0x30000) appears on the serial output when performing TFTP reset. 0x30000 is probably the size of the first boot loader for all variants. But you can only find this out if you have the serial console. If you think it's not for your variant, well. Shotgun it(trial and error). I highly doubt it's other than 0x30000, though.

The first boot loader never touches its region(0x0 - 0x30000). The first boot loader will always be there to help you(unless you manually modified it). As long as the first boot loader is intact, you can debrick your hw. Cheers.

https://github.com/ashegoulding/tp-link_c20-v5.dev